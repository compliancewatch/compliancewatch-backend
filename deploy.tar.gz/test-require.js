const path = require('path');
const targets = require('./config/targets.js');
console.log('First target:', targets.REGULATORY_TARGETS[0].name);
